# Distort.io

A real-time text-telephone game: a hidden theme travels down a chain of
players while an AI "Mutation Engine" warps each message before the next
player sees it. Players are scored on how close they stay to the secret
theme, plus a bonus for pulling the conversation back on track after heavy
distortion.

This is a genuinely runnable implementation of the architectural spec:
Socket.io real-time transport, a turn-based game loop, an AI-powered
mutation pipeline (calls Claude), and a scoring/leaderboard system.

## What's different from the full spec, and why

The original spec calls for Redis + PostgreSQL/Prisma for state and
persistence. For a project you can `npm install` and run locally in minutes,
this build uses a single in-memory store (`server/src/rooms.js`) that is
**deliberately structured to match the spec's Redis layout** (room hash,
player-order list, score map standing in for a ZSET). Swapping in real Redis
for shared state across multiple server instances, or Postgres/Prisma to
persist finished "Story Artifacts," is a drop-in change to that one file —
nothing else in the app needs to know the difference.

Everything else — the Socket.io server, the turn state machine, the AI
mutation calls, the scoring formula, and the full Next.js client — is real,
working code, not a mockup.

## Project layout

```
distort-io/
  server/     Express + Socket.io game server (Node, ESM)
  client/     Next.js frontend
```

## 1. Get an Anthropic API key

The Mutation Engine calls Claude to creatively distort each message. Grab a
key from https://console.anthropic.com if you don't have one.

## 2. Run the server

```bash
cd server
npm install
cp .env.example .env
# edit .env and paste your ANTHROPIC_API_KEY
npm run dev
```

The server listens on `http://localhost:4000` by default.

## 3. Run the client

In a second terminal:

```bash
cd client
npm install
npm run dev
```

Open `http://localhost:3000`.

## 4. Play

1. On the home page, click **Host a room**, enter your name and a secret
   theme (e.g. "A distress signal from an abandoned deep-sea submarine"),
   and pick a number of turns.
2. Share the 5-character room code with other players — have them open
   `http://localhost:3000`, click **Join a room**, and enter it.
3. Once at least 2 players are in, the host clicks **Start transmission**.
4. On your turn, type a message continuing the story. The engine distorts
   it before the next player sees it. You're scored on how close your
   *own* message stayed to the hidden theme, plus a resilience bonus if you
   steered the conversation back on-topic despite garbled input.
5. After the final turn, everyone sees the full "Story Artifact" transcript
   and final leaderboard.

## Notes for running with multiple players on one machine

Open the client in separate browser profiles or incognito windows — each
browser tab gets its own Socket.io connection (and therefore its own
player identity).

## Extending toward the full production spec

- **Redis**: replace the `Map`s in `server/src/rooms.js` with real Redis
  calls (`HSET room:{id}`, `RPUSH room:{id}:queue`, `ZADD` for the
  leaderboard) — the function signatures already match that shape.
- **PostgreSQL + Prisma**: persist the `messages` array and final
  leaderboard as a `StoryArtifact` row when a room's status flips to
  `finished`.
- **Embeddings-based scoring**: swap `topicProximity` in
  `server/src/scoring.js` for a real embedding call and cosine similarity;
  every call site is already isolated to that one function.
- **Deployment**: server to Render/Railway, client to Vercel, per the
  spec's Phase 5.
