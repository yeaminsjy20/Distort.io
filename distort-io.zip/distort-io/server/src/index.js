import "dotenv/config";
import express from "express";
import http from "http";
import cors from "cors";
import { Server } from "socket.io";

import {
  createRoom,
  getRoom,
  joinRoom,
  removePlayer,
  startGame,
  currentPlayerId,
  recordTurn,
  publicRoomState,
  listOpenLobbies,
} from "./rooms.js";
import { mutateText, generateSeedTransmission } from "./mutation.js";
import { scoreTurn } from "./scoring.js";

const PORT = process.env.PORT || 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "http://localhost:3000";

const app = express();
app.use(cors({ origin: CLIENT_ORIGIN }));
app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("/lobbies", (_req, res) => res.json(listOpenLobbies()));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: CLIENT_ORIGIN, methods: ["GET", "POST"] },
});

function broadcastRoom(room) {
  io.to(room.id).emit("room:state", publicRoomState(room));
}

io.on("connection", (socket) => {
  socket.on("room:create", ({ theme, maxTurns, hostName }, ack) => {
    if (!theme?.trim()) return ack?.({ error: "A secret theme is required." });
    const room = createRoom({
      theme: theme.trim(),
      maxTurns: Math.min(Math.max(Number(maxTurns) || 8, 3), 20),
      hostSocketId: socket.id,
      hostName: hostName?.trim() || "Host",
    });
    socket.join(room.id);
    ack?.({ roomId: room.id });
    broadcastRoom(room);
  });

  socket.on("room:join", ({ roomId, name }, ack) => {
    const room = joinRoom(roomId?.toUpperCase(), socket.id, name?.trim() || "Player");
    if (!room) return ack?.({ error: "Room not found." });
    if (room.status !== "lobby") return ack?.({ error: "That game already started." });
    socket.join(room.id);
    ack?.({ roomId: room.id });
    broadcastRoom(room);
  });

  socket.on("room:start", async ({ roomId }, ack) => {
    const room = getRoom(roomId);
    if (!room) return ack?.({ error: "Room not found." });
    if (socket.id !== room.hostSocketId) return ack?.({ error: "Only the host can start the game." });
    if (room.playerOrder.length < 2) return ack?.({ error: "Need at least 2 players." });

    try {
      const seed = await generateSeedTransmission(room.theme);
      startGame(roomId);
      room.messages.push({
        turn: 0,
        authorSocketId: null,
        submittedText: room.theme,
        mutatedOutput: seed,
        topicScore: null,
        resilienceBonus: null,
        turnTotal: 0,
      });
      ack?.({ ok: true });
      broadcastRoom(room);
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on("turn:submit", async ({ roomId, text }, ack) => {
    const room = getRoom(roomId);
    if (!room) return ack?.({ error: "Room not found." });
    if (room.status !== "active") return ack?.({ error: "Game isn't active." });
    if (currentPlayerId(room) !== socket.id) return ack?.({ error: "It isn't your turn." });
    if (!text?.trim()) return ack?.({ error: "Message can't be empty." });

    const turnNumber = room.turnIndex + 1;
    const priorMessage = room.messages[room.messages.length - 1];
    const mutatedInputReceived = priorMessage?.mutatedOutput || room.theme;

    try {
      const { topicScore, resilienceBonus, turnTotal } = scoreTurn({
        submittedText: text,
        mutatedInputReceived,
        theme: room.theme,
      });

      const mutatedOutput = await mutateText({
        text: text.trim(),
        turnIndex: turnNumber,
        intensity: 1 + Math.floor((turnNumber / room.maxTurns) * 4),
      });

      recordTurn(room, {
        turn: turnNumber,
        authorSocketId: socket.id,
        submittedText: text.trim(),
        mutatedOutput,
        topicScore,
        resilienceBonus,
        turnTotal,
      });

      ack?.({ ok: true, topicScore, resilienceBonus });
      broadcastRoom(room);
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on("disconnect", () => {
    removePlayer(socket.id);
    for (const roomId of socket.rooms) {
      const room = getRoom(roomId);
      if (room) broadcastRoom(room);
    }
  });
});

server.listen(PORT, () => {
  console.log(`Distort.io server listening on :${PORT}`);
});
