// The Mutation Engine: warps a player's text before the next player sees it.
// Uses Claude to perform creative, controllable distortion (synonym drift,
// noise injection, stylistic rewrites) instead of hand-rolled string rules.

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-5";

const STYLES = [
  "synonym drift — swap words for near-synonyms that subtly shift meaning",
  "noise injection — sprinkle in garbled, static-like fragments and glitch characters without destroying legibility",
  "stylistic overwrite — rewrite it in an exaggerated, unrelated register (e.g. corporate memo, pirate speak, ancient prophecy)",
  "fragmentation — break the sentence apart and reorder clauses, like a signal cutting in and out",
  "euphemism cascade — replace concrete nouns/verbs with vaguer, roundabout phrasing",
];

function pickStyle(turnIndex) {
  return STYLES[turnIndex % STYLES.length];
}

/**
 * Mutates `text` using Claude. `intensity` is 1-5 (scales with turn number)
 * and controls how aggressively the engine distorts the message.
 */
export async function mutateText({ text, turnIndex = 0, intensity = 2 }) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "ANTHROPIC_API_KEY is not set on the server. Add it to server/.env"
    );
  }

  const style = pickStyle(turnIndex);
  const clampedIntensity = Math.max(1, Math.min(5, intensity));

  const system = `You are the "Mutation Engine" inside a text-telephone game called Distort.io.
Your only job is to distort a short message before the next player sees it.

Technique for this turn: ${style}.
Distortion intensity: ${clampedIntensity}/5 (1 = barely perceptible, 5 = heavily garbled but still partially readable).

Rules:
- Preserve enough of the original meaning that a sharp player could still guess at the underlying idea.
- Never add real-world facts, instructions, or content that wasn't implied by the input.
- Never break character or explain what you did.
- Output ONLY the mutated text. No preamble, no quotes, no commentary.`;

  const response = await fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 300,
      system,
      messages: [{ role: "user", content: text }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    throw new Error(`Mutation engine call failed (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const mutated = (data.content || [])
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();

  return mutated || text;
}

/**
 * Generates the opening transmission for turn 1 from the room's secret theme,
 * so players 1 never simply sees the raw secret prompt verbatim.
 */
export async function generateSeedTransmission(theme) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "ANTHROPIC_API_KEY is not set on the server. Add it to server/.env"
    );
  }

  const system = `You write the opening line of a mysterious in-fiction transmission for a party game, based on a hidden theme the players will never see directly.
Write 1-2 short, evocative sentences that could plausibly open a story about the theme, without stating the theme's exact wording.
Output ONLY the transmission text, no preamble or quotes.`;

  const response = await fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 150,
      system,
      messages: [{ role: "user", content: `Hidden theme: ${theme}` }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    throw new Error(`Seed generation failed (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const seed = (data.content || [])
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();

  return seed || "...the signal begins, faint and uncertain...";
}
