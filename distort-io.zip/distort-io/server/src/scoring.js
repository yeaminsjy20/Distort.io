// Lightweight topic-proximity scorer.
//
// The spec calls for "cosine similarity of text embeddings or token overlap
// against the secret prompt." We use a dependency-free weighted token-overlap
// score (Jaccard over stemmed-ish tokens, weighted by rarity) so the game
// runs with zero external services. Swap this for a real embedding call
// (e.g. an embeddings API) later without touching any other module.

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "but", "of", "in", "on", "at", "to", "is",
  "are", "was", "were", "be", "been", "it", "its", "this", "that", "with",
  "for", "as", "by", "from", "into", "over", "under", "up", "down", "we",
  "you", "i", "they", "he", "she", "them", "our", "your", "my", "his", "her",
]);

function tokenize(text) {
  return (text || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOPWORDS.has(t));
}

// Naive suffix-stripping to loosely group word forms (mutate/mutated/mutation).
function stem(token) {
  return token.replace(/(ing|ations?|ed|ers?|es|s)$/i, "");
}

function tokenSet(text) {
  return new Set(tokenize(text).map(stem));
}

/**
 * Returns a 0-100 proximity score between a candidate string and the secret
 * theme, using weighted Jaccard overlap. Shared rare words count more than
 * shared common words.
 */
export function topicProximity(candidate, theme) {
  const a = tokenSet(candidate);
  const b = tokenSet(theme);
  if (a.size === 0 || b.size === 0) return 0;

  let shared = 0;
  for (const tok of a) {
    if (b.has(tok)) shared += 1;
  }
  const union = new Set([...a, ...b]).size;
  const jaccard = shared / union;

  // Small bonus for absolute overlap count so longer, on-topic messages
  // aren't penalized purely for using more (varied) words than the theme.
  const overlapBonus = Math.min(shared * 4, 20);

  return Math.round(Math.min(100, jaccard * 100 + overlapBonus));
}

/**
 * Turn scoring per the spec's dual-metric formula:
 *  - Stopic: proximity of the player's own submitted text to the secret theme
 *  - Bresilience: bonus for pulling proximity back up despite receiving
 *    heavily mutated input
 */
export function scoreTurn({ submittedText, mutatedInputReceived, theme }) {
  const sTopic = topicProximity(submittedText, theme);
  const inputProximity = mutatedInputReceived
    ? topicProximity(mutatedInputReceived, theme)
    : sTopic;

  const recovered = Math.max(0, sTopic - inputProximity);
  const bResilience = Math.round(Math.min(30, recovered * 0.6));

  return {
    topicScore: sTopic,
    resilienceBonus: bResilience,
    turnTotal: sTopic + bResilience,
  };
}
