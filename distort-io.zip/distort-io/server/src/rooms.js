// In-memory state store, deliberately shaped like the spec's Redis design so
// swapping in real Redis later is a drop-in change:
//   room:{id}          -> Hash   (this module: `rooms` Map)
//   room:{id}:queue     -> List   (this module: `room.playerOrder` array)
//   room:{id}:leaderboard -> ZSET (this module: `room.scores` Map, resorted on read)
//
// A real deployment would back this with Redis for shared state across
// server instances, and Postgres/Prisma for persisted Story Artifacts. For a
// single local server process, an in-memory Map is a faithful, zero-infra
// stand-in with the exact same access patterns.

import { customAlphabet } from "nanoid";

const makeRoomId = customAlphabet("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 5);

const rooms = new Map();

export function createRoom({ theme, maxTurns, hostSocketId, hostName }) {
  const id = makeRoomId();
  const room = {
    id,
    theme, // secret — never sent to clients directly
    maxTurns,
    status: "lobby", // lobby | active | finished
    hostSocketId,
    players: new Map(), // socketId -> { name, joinedAt }
    playerOrder: [], // the turn queue (List)
    turnIndex: 0,
    messages: [], // { turn, authorSocketId, submittedText, mutatedOutput, ... }
    scores: new Map(), // socketId -> total score (ZSET stand-in)
    createdAt: Date.now(),
  };
  room.players.set(hostSocketId, { name: hostName, joinedAt: Date.now() });
  room.playerOrder.push(hostSocketId);
  room.scores.set(hostSocketId, 0);
  rooms.set(id, room);
  return room;
}

export function getRoom(id) {
  return rooms.get(id);
}

export function joinRoom(id, socketId, name) {
  const room = rooms.get(id);
  if (!room) return null;
  if (room.status !== "lobby") return room;
  if (!room.players.has(socketId)) {
    room.players.set(socketId, { name, joinedAt: Date.now() });
    room.playerOrder.push(socketId);
    room.scores.set(socketId, 0);
  }
  return room;
}

export function removePlayer(socketId) {
  for (const room of rooms.values()) {
    if (room.players.has(socketId)) {
      room.players.delete(socketId);
      room.playerOrder = room.playerOrder.filter((id) => id !== socketId);
      // Leave score history intact for the leaderboard/story artifact even
      // if the player disconnects mid-game.
    }
  }
}

export function startGame(id) {
  const room = rooms.get(id);
  if (!room) return null;
  room.status = "active";
  room.turnIndex = 0;
  return room;
}

export function currentPlayerId(room) {
  if (room.playerOrder.length === 0) return null;
  return room.playerOrder[room.turnIndex % room.playerOrder.length];
}

export function recordTurn(room, entry) {
  room.messages.push(entry);
  const prior = room.scores.get(entry.authorSocketId) || 0;
  room.scores.set(entry.authorSocketId, prior + entry.turnTotal);
  room.turnIndex += 1;
  if (room.turnIndex >= room.maxTurns) {
    room.status = "finished";
  }
  return room;
}

export function leaderboard(room) {
  return [...room.scores.entries()]
    .map(([socketId, total]) => ({
      socketId,
      name: room.players.get(socketId)?.name || "departed player",
      total,
    }))
    .sort((a, b) => b.total - a.total);
}

export function publicRoomState(room) {
  return {
    id: room.id,
    status: room.status,
    maxTurns: room.maxTurns,
    turnIndex: room.turnIndex,
    players: [...room.players.entries()].map(([socketId, p]) => ({
      socketId,
      name: p.name,
    })),
    currentPlayerId: currentPlayerId(room),
    messages: room.messages.map((m) => ({
      turn: m.turn,
      authorName: room.players.get(m.authorSocketId)?.name || "departed player",
      mutatedOutput: m.mutatedOutput,
      topicScore: m.topicScore,
      resilienceBonus: m.resilienceBonus,
    })),
    leaderboard: leaderboard(room),
  };
}

export function listOpenLobbies() {
  return [...rooms.values()]
    .filter((r) => r.status === "lobby")
    .map((r) => ({
      id: r.id,
      players: r.players.size,
      maxTurns: r.maxTurns,
      createdAt: r.createdAt,
    }));
}
