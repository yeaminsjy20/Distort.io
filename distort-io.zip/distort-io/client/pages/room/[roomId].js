import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { getSocket } from "../../lib/socket";
import Leaderboard from "../../components/Leaderboard";
import StoryArtifactModal from "../../components/StoryArtifactModal";

export default function Room() {
  const router = useRouter();
  const { roomId } = router.query;
  const [state, setState] = useState(null);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [lastScore, setLastScore] = useState(null);
  const [sending, setSending] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const feedEndRef = useRef(null);
  const socketRef = useRef(null);

  useEffect(() => {
    if (!roomId) return;
    const socket = getSocket();
    socketRef.current = socket;
    socket.emit("room:join", { roomId, name: sessionStorage.getItem("distort:name") || "Player" }, () => {});
    socket.on("room:state", (s) => setState(s));
    return () => {
      socket.off("room:state");
    };
  }, [roomId]);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state?.messages?.length]);

  useEffect(() => {
    if (state?.status === "finished") setShowArtifact(true);
  }, [state?.status]);

  if (!state) {
    return (
      <main style={styles.loading}>
        <p className="eyebrow">Locating channel {roomId}...</p>
      </main>
    );
  }

  const you = socketRef.current?.id;
  const isHost = state.players[0]?.socketId === you;
  const isYourTurn = state.currentPlayerId === you;

  function handleStart() {
    setError("");
    socketRef.current.emit("room:start", { roomId }, (res) => {
      if (res?.error) setError(res.error);
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!draft.trim()) return;
    setSending(true);
    setError("");
    socketRef.current.emit("turn:submit", { roomId, text: draft }, (res) => {
      setSending(false);
      if (res?.error) return setError(res.error);
      setLastScore(res);
      setDraft("");
    });
  }

  return (
    <>
      <div className="static-veil" />
      <main style={styles.main}>
        <header style={styles.header}>
          <div>
            <div className="eyebrow">Room {roomId}</div>
            <h1 style={{ margin: "0.2rem 0" }}>
              Turn {Math.min(state.turnIndex + 1, state.maxTurns)} / {state.maxTurns}
            </h1>
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.8rem", color: "var(--static-dim)" }}>
            {state.players.map((p) => p.name).join(" · ")}
          </div>
        </header>

        <div style={styles.body}>
          <section className="panel" style={styles.feed}>
            {state.status === "lobby" && (
              <div style={styles.centered}>
                <p style={{ color: "var(--static-dim)" }}>
                  Waiting in the lobby. {state.players.length} player(s) connected.
                </p>
                {isHost ? (
                  <button className="btn primary" onClick={handleStart} disabled={state.players.length < 2}>
                    {state.players.length < 2 ? "Need 2+ players" : "Start transmission"}
                  </button>
                ) : (
                  <p className="eyebrow">Waiting for host to start&hellip;</p>
                )}
              </div>
            )}

            {state.messages.map((m, i) => (
              <div key={i} style={styles.message}>
                <div className="eyebrow" style={{ marginBottom: "0.3rem" }}>
                  Turn {m.turn} &middot; {m.authorName}
                  {m.topicScore !== null && (
                    <span className="scoreflash" style={{ marginLeft: "0.6rem" }}>
                      +{m.topicScore} topic
                      {m.resilienceBonus > 0 ? ` +${m.resilienceBonus} resilience` : ""}
                    </span>
                  )}
                </div>
                <div className="transmission glitching" data-text={m.mutatedOutput}>
                  {m.mutatedOutput}
                </div>
              </div>
            ))}
            <div ref={feedEndRef} />

            {state.status === "finished" && (
              <div style={styles.centered}>
                <p className="eyebrow">Channel closed.</p>
                <button className="btn" onClick={() => setShowArtifact(true)}>
                  View story artifact
                </button>
              </div>
            )}
          </section>

          <aside style={styles.sidebar}>
            <Leaderboard entries={state.leaderboard} youId={you} />
          </aside>
        </div>

        {state.status === "active" && (
          <form className="panel" style={styles.composer} onSubmit={handleSubmit}>
            <textarea
              rows={2}
              placeholder={isYourTurn ? "Send your transmission..." : "Waiting for your turn..."}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              disabled={!isYourTurn || sending}
              style={{ flex: 1 }}
            />
            <button className="btn primary" type="submit" disabled={!isYourTurn || sending}>
              {sending ? "Transmitting..." : "Send"}
            </button>
          </form>
        )}

        {error && <p style={{ color: "var(--magenta)", fontFamily: "var(--font-mono)" }}>{error}</p>}
      </main>

      {showArtifact && (
        <StoryArtifactModal
          messages={state.messages.filter((m) => m.turn > 0)}
          leaderboard={state.leaderboard}
          onClose={() => setShowArtifact(false)}
        />
      )}
    </>
  );
}

const styles = {
  loading: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--static-dim)",
  },
  main: {
    position: "relative",
    zIndex: 1,
    minHeight: "100vh",
    maxWidth: 960,
    margin: "0 auto",
    padding: "1.5rem",
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
  header: { display: "flex", justifyContent: "space-between", alignItems: "flex-end" },
  body: { display: "grid", gridTemplateColumns: "1fr 260px", gap: "1rem", minHeight: 400 },
  feed: { padding: "1.25rem", overflowY: "auto", maxHeight: "60vh" },
  sidebar: { display: "flex", flexDirection: "column", gap: "1rem" },
  message: { marginBottom: "1.25rem" },
  centered: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "0.75rem",
    padding: "2rem 0",
    textAlign: "center",
  },
  composer: { display: "flex", gap: "0.75rem", padding: "1rem" },
};
