import { useState } from "react";
import { useRouter } from "next/router";
import { getSocket } from "../lib/socket";

export default function Home() {
  const router = useRouter();
  const [mode, setMode] = useState("create");
  const [hostName, setHostName] = useState("");
  const [theme, setTheme] = useState("");
  const [maxTurns, setMaxTurns] = useState(8);
  const [joinName, setJoinName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function handleCreate(e) {
    e.preventDefault();
    setError("");
    if (!theme.trim()) return setError("The signal needs a secret theme.");
    setBusy(true);
    const socket = getSocket();
    socket.emit(
      "room:create",
      { theme, maxTurns, hostName: hostName || "Host" },
      (res) => {
        setBusy(false);
        if (res?.error) return setError(res.error);
        sessionStorage.setItem("distort:name", hostName || "Host");
        router.push(`/room/${res.roomId}`);
      }
    );
  }

  function handleJoin(e) {
    e.preventDefault();
    setError("");
    if (!joinCode.trim()) return setError("Enter a room code.");
    setBusy(true);
    const socket = getSocket();
    socket.emit(
      "room:join",
      { roomId: joinCode.trim(), name: joinName || "Player" },
      (res) => {
        setBusy(false);
        if (res?.error) return setError(res.error);
        sessionStorage.setItem("distort:name", joinName || "Player");
        router.push(`/room/${res.roomId}`);
      }
    );
  }

  return (
    <>
      <div className="static-veil" />
      <main style={styles.main}>
        <div style={styles.hero}>
          <div className="eyebrow">// transmission relay game</div>
          <h1 style={styles.title}>
            DISTORT<span style={{ color: "var(--magenta)" }}>.</span>IO
          </h1>
          <p style={styles.sub}>
            A secret theme drifts down a chain of players. Every hop, a machine
            in the middle warps the signal. Stay close to the truth &mdash;
            or find out how far you can bend it.
          </p>
        </div>

        <div style={styles.tabs}>
          <button
            className="btn"
            style={mode === "create" ? styles.tabActive : {}}
            onClick={() => setMode("create")}
          >
            Host a room
          </button>
          <button
            className="btn"
            style={mode === "join" ? styles.tabActive : {}}
            onClick={() => setMode("join")}
          >
            Join a room
          </button>
        </div>

        {mode === "create" ? (
          <form className="panel" style={styles.form} onSubmit={handleCreate}>
            <label style={styles.label}>
              Your name
              <input
                value={hostName}
                onChange={(e) => setHostName(e.target.value)}
                placeholder="Operator"
              />
            </label>
            <label style={styles.label}>
              Secret theme (hidden from every player)
              <textarea
                rows={2}
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                placeholder="A distress signal from an abandoned deep-sea submarine"
              />
            </label>
            <label style={styles.label}>
              Turns
              <input
                type="number"
                min={3}
                max={20}
                value={maxTurns}
                onChange={(e) => setMaxTurns(e.target.value)}
              />
            </label>
            <button className="btn primary" disabled={busy} type="submit">
              {busy ? "Opening channel..." : "Create room"}
            </button>
          </form>
        ) : (
          <form className="panel" style={styles.form} onSubmit={handleJoin}>
            <label style={styles.label}>
              Your name
              <input
                value={joinName}
                onChange={(e) => setJoinName(e.target.value)}
                placeholder="Player"
              />
            </label>
            <label style={styles.label}>
              Room code
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                placeholder="XJ4K9"
                style={{ letterSpacing: "0.2em" }}
              />
            </label>
            <button className="btn primary" disabled={busy} type="submit">
              {busy ? "Tuning in..." : "Join room"}
            </button>
          </form>
        )}

        {error && <p style={styles.error}>{error}</p>}
      </main>
    </>
  );
}

const styles = {
  main: {
    position: "relative",
    zIndex: 1,
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "2rem",
    gap: "1.5rem",
  },
  hero: { maxWidth: 520, textAlign: "center" },
  title: {
    fontSize: "3.2rem",
    margin: "0.5rem 0",
    letterSpacing: "-0.02em",
  },
  sub: { color: "var(--static-dim)", lineHeight: 1.6 },
  tabs: { display: "flex", gap: "0.75rem" },
  tabActive: { background: "var(--cyan)", color: "var(--bg)" },
  form: {
    width: 360,
    padding: "1.5rem",
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
  label: {
    display: "flex",
    flexDirection: "column",
    gap: "0.4rem",
    fontSize: "0.85rem",
    color: "var(--static-dim)",
  },
  error: { color: "var(--magenta)", fontFamily: "var(--font-mono)", fontSize: "0.85rem" },
};
