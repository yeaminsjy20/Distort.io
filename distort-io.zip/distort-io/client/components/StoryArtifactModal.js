export default function StoryArtifactModal({ messages, leaderboard, onClose }) {
  const transcript = messages
    .map((m) => `[Turn ${m.turn}] ${m.authorName}: ${m.mutatedOutput}`)
    .join("\n\n");

  function copyArtifact() {
    navigator.clipboard.writeText(transcript);
  }

  return (
    <div style={overlay}>
      <div className="panel" style={modal}>
        <div className="eyebrow">Story artifact // channel closed</div>
        <h2 style={{ margin: "0.5rem 0 1rem" }}>Final transmission log</h2>
        <div style={log}>
          {messages.map((m, i) => (
            <p key={i} style={{ margin: "0 0 0.85rem", lineHeight: 1.5 }}>
              <span style={{ color: "var(--cyan)", fontFamily: "var(--font-mono)", fontSize: "0.75rem" }}>
                TURN {m.turn} &middot; {m.authorName}
              </span>
              <br />
              {m.mutatedOutput}
            </p>
          ))}
        </div>

        <div className="eyebrow" style={{ marginTop: "1rem" }}>
          Final ranking
        </div>
        <ol style={{ paddingLeft: "1.2rem" }}>
          {leaderboard.map((e) => (
            <li key={e.socketId} style={{ fontFamily: "var(--font-mono)", fontSize: "0.9rem" }}>
              {e.name} &mdash; {e.total} pts
            </li>
          ))}
        </ol>

        <div style={{ display: "flex", gap: "0.75rem", marginTop: "1.25rem" }}>
          <button className="btn" onClick={copyArtifact}>
            Copy transcript
          </button>
          <button className="btn primary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.75)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 10,
  padding: "1.5rem",
};

const modal = {
  maxWidth: 560,
  width: "100%",
  maxHeight: "85vh",
  overflowY: "auto",
  padding: "1.5rem",
};

const log = {
  borderTop: "1px solid var(--line)",
  borderBottom: "1px solid var(--line)",
  padding: "1rem 0",
};
