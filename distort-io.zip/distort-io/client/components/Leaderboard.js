export default function Leaderboard({ entries, youId }) {
  return (
    <div className="panel" style={{ padding: "1rem" }}>
      <div className="eyebrow" style={{ marginBottom: "0.75rem" }}>
        Leaderboard
      </div>
      <ol style={{ listStyle: "none", margin: 0, padding: 0 }}>
        {entries.map((entry, i) => (
          <li
            key={entry.socketId}
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "0.4rem 0",
              borderBottom: "1px solid var(--line)",
              color: entry.socketId === youId ? "var(--cyan)" : "var(--static)",
              fontFamily: "var(--font-mono)",
              fontSize: "0.85rem",
            }}
          >
            <span>
              {String(i + 1).padStart(2, "0")}. {entry.name}
              {entry.socketId === youId ? " (you)" : ""}
            </span>
            <span>{entry.total}</span>
          </li>
        ))}
        {entries.length === 0 && (
          <li style={{ color: "var(--static-dim)", fontSize: "0.85rem" }}>
            No signal yet.
          </li>
        )}
      </ol>
    </div>
  );
}
